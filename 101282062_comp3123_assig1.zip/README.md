# 101282062_comp3123_assig1
Basic NodeJS application using expressJS framework to create a REST API.
